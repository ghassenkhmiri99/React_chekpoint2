const players = [{
    name: "khabib nurmagomedov",
    team: "Eagles",
    nationality: "Russian",
    jerseyNumber: 29,
    age: 35,
    image: require('./Khabib.jpg')

},
{
    name: "Mike Tyson",
    team: "Irons",
    nationality: "American",
    jerseyNumber: 50,
    age: 57,
    image: require('./Tyson.jpg')
},
{
    name: "fedor Emelianenko",
    team: "Emperors",
    nationality: "Russian",
    jerseyNumber: 40,
    age: 46,
    image: require('./Fedor.webp')
},
{
    name: "Tyson fury",
    team: "Gypsies",
    nationality: "British",
    jerseyNumber: 33,
    age: 35,
    image: require('./Fury.webp')
}

];

export default players;