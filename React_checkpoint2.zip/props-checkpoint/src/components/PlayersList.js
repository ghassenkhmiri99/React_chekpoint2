import players from "./players";
import Player from "./Player";

function PlayersList() {
    const playerObject = players.map(element => <Player {...element} />);
    return (
        <div style={{
        display: 'flex',
        justifyContent: 'space-around',
        alignItems: 'center',

    }}>{playerObject}</div>);
}

export default PlayersList;