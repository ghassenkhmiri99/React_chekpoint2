import logo from './logo.svg';
import './App.css';
import PlayersList from './components/PlayersList';
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <div className="App">
      <PlayersList/>
    </div>
  );
}

export default App;
